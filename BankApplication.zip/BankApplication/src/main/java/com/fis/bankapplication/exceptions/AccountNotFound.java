package com.fis.bankapplication.exceptions;

//Exception to check if the account given is valid or not
public class AccountNotFound extends RuntimeException {
	public AccountNotFound(String message) {
		super(message);
	}
}