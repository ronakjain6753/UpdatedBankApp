package com.fis.bankapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	// Method for adding new customer
	@PostMapping("/addCustomer") // http://localhost:8080/customers/addCustomer
	public String addCustomer(@RequestBody @Validated Customer customer) {
		return customerService.addCustomer(customer);
	}

	// Method for updating a customer
	@PutMapping("/updateCustomer") // http://localhost:8080/customers/updateCustomer
	public String updateCustomer(@RequestBody @Validated Customer customer) {
		return customerService.updateCustomer(customer);
	}

	// Method for deleting a customer
	@DeleteMapping("/deleteCustomer/{customerId}") // http://localhost:8080/customers/deleteCustomer/1
	public String deleteCustomer(@PathVariable("customerId") long customerId) throws CustomerNotFound {
		return customerService.deleteCustomer(customerId);
	}

	// Method for getting a customer by customer id
	@GetMapping("/getCustomer/{customerId}") // http://localhost:8080/customers/getCustomer/1
	public Customer getCustomer(@PathVariable("customerId") long customerId) throws CustomerNotFound {
		Customer customer = customerService.getCustomer(customerId);
		return customer;
	}

	// Method for getting all customers in one go
	@GetMapping("/getAllCustomers") // http://localhost:8080/customers/getAllCustomers
	public List<Customer> getAllCustomers() {
		List<Customer> customers = customerService.getAllCustomers();
		return customers;
	}
}