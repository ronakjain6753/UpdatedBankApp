package com.fis.bankapplication.exceptions;

//Exception to check if the customer details are valid or not
public class CustomerNotFound extends RuntimeException {

	public CustomerNotFound(String message) {
		super(message);
	}

}