package com.fis.bankapplication.exceptions;

//Exception to check if transaction is valid or not
public class TransactionNotFound extends RuntimeException {
	public TransactionNotFound(String message) {
		super(message);
	}
}