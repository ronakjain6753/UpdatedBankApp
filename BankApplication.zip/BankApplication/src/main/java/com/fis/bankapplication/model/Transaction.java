package com.fis.bankapplication.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "transactions")
public class Transaction {

	// Automatically generated transaction id
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transaction_id")
	private long id;

	// Asking for source account from which transaction is done and validating it
	@NotNull(message = "Source Account is required")
	@ManyToOne
	@JoinColumn(name = "account_from_id", referencedColumnName = "account_id")
//    private long accountFrom;
	private Account accountFrom;

	// Asking for beneficiary account to which transaction needs to be done and
	// validating it
	@NotNull(message = "Beneficiary Account is required")
	@ManyToOne
	@JoinColumn(name = "account_to_id", referencedColumnName = "account_id")
//    private long accountTo;
	private Account accountTo;

	// Validating amount given as it cannot be a negative value and initializing its
	// value as 1
	@Min(value = 1, message = "Amount cannot be less than 1")
	@NotNull(message = "Amount is required")
	@Column(name = "amount")
	private double amount;

	// Validating date of transaction
	@NotNull(message = "Date of Transaction is required")
	@Column(name = "date_of_transaction")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy") //
	private Date dateOfTransaction;

	// Validating transaction type
	@NotNull(message = "Transaction type is required")
	@Column(name = "transaction_type")
	private String transactionType;

	public Transaction(Account accountFrom, Account accountTo, double amount, String transactionType,
			Date dateOfTransaction) {
//		this.id = id;
		this.accountFrom = accountFrom;
		this.accountTo = accountTo;
		this.amount = amount;
		this.transactionType = transactionType;
		this.dateOfTransaction = dateOfTransaction;
	}

	public Transaction() {

	}

	// Required getters and setters
	public Account getAccountFrom() {
		return accountFrom;
	}

	public void setAccountFrom(Account accountFrom) {
		this.accountFrom = accountFrom;
	}

	public Account getAccountTo() {
		return accountTo;
	}

	public void setAccountTo(Account accountTo) {
		this.accountTo = accountTo;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
}