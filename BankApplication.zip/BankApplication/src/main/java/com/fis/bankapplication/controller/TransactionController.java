package com.fis.bankapplication.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.TransactionService;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	// Method to add transaction
	@PostMapping("/addTransaction") // http://localhost:8080/transactions/addTransaction
	public String createTransaction(@RequestBody Transaction transaction) {
		return transactionService.addTransaction(transaction);
	}

	// Method to get transaction by transaction Id
	@GetMapping("/getTransaction/{transactionId}") // http://localhost:8080/transactions/getTransaction/1
	public Transaction getTransaction(@PathVariable("transactionId") long transactionId) {
		Transaction transaction = transactionService.getTransactionById(transactionId);
		return transaction;
	}

	// Method to get account statement by account id like how many transaction are
	// done where and when
	@GetMapping("/account/{accountId}") // http://localhost:8080/transactions/account/1
	public List<Transaction> getAccountStatementsByDateRange(@PathVariable("accountId") long accountId,
			@RequestParam("startDate") @DateTimeFormat(pattern = "dd-MM-yyyy") Date startDate,
			@RequestParam("endDate") @DateTimeFormat(pattern = "dd-MM-yyyy") Date endDate) {
		List<Transaction> accountStatements = transactionService.getAccountStatementsByDateRange(accountId, startDate,
				endDate);
		return accountStatements;
	}

	// Method to get all transactions in one go
	@GetMapping("/account/{accountId}/allTransactions") // http://localhost:8080/transactions/account/1/allTransactions
	public List<Transaction> getTransactionsForAccount(@PathVariable("accountId") long accountId) {
		List<Transaction> allTransactions = transactionService.getTransactionsForAccount(accountId);
		return allTransactions;
	}
}