package com.fis.bankapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.service.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService accountService;

	// Method for adding account
	@PostMapping("/addAccount") // http://localhost:8080/accounts/addAccount
	public String addAccount(@RequestBody @Validated Account account) {
		return accountService.addAccount(account);
	}

	// Method for updating account
	@PutMapping("/updateAccount") // http://localhost:8080/accounts/updateAccount
	public String updateAccount(@RequestBody @Validated Account account) {
		return accountService.updateAccount(account);
	}

	// Method for deleting account
	@DeleteMapping("/deleteAccount/{accountId}") // http://localhost:8080/accounts/deleteAccount/1
	public String deleteAccount(@PathVariable("accountId") long accountId) throws AccountNotFound {
		return accountService.deleteAccount(accountId);
	}

	// Method for getting account by account id
	@GetMapping("/getAccount/{accountId}") // http://localhost:8080/accounts/getAccount/1
	public Account getAccount(@PathVariable("accountId") long accountId) throws AccountNotFound {
		Account account = accountService.getAccount(accountId);
		return account;
	}

	// Method to get all accounts in one go
	@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
	public List<Account> getAllAccounts() {
		List<Account> accounts = accountService.getAllAccounts();
		return accounts;
	}

	// Method for depositing a particular amount
	@PostMapping("/deposit") // http://localhost:8080/accounts/deposit
	public String deposit(@RequestParam("accountId") long accountId, @RequestParam("amount") double amount) {
		String response = accountService.deposit(accountId, amount);
		return response;
	}

	// Method for withdrawing a particular amount
	@PostMapping("/withdraw") // http://localhost:8080/accounts/withdraw
	public String withdraw(@RequestParam("accountId") long accountId, @RequestParam("amount") double amount) {
		String response = accountService.withdraw(accountId, amount);
		return response;
	}

	// Method for transferring fund from one account to another
	@PostMapping("/fundTransfer") // http://localhost:8080/accounts/fundTransfer
	public String fundTransfer(@RequestParam("fromAccountNumber") long fromAccountNumber,
			@RequestParam("toAccountNumber") long toAccountNumber, @RequestParam("amount") double amount,
			@RequestParam("transactionType") String transactionType) {
		String response = accountService.fundTransfer(fromAccountNumber, toAccountNumber, amount, transactionType);
		return response;
	}

	// Method for getting account by customer id
	@GetMapping("/by-customer/{customerId}") // http://localhost:8080/accounts/by-customer/1
	public List<Account> getAccountsByCustomerId(@PathVariable("customerId") long customerId) {
		List<Account> accounts = accountService.getAccountsByCustomerId(customerId);
		return accounts;
	}

	// Method for getting total balance of an account using customer id
	@GetMapping("/total-balance/{customerId}") // http://localhost:8080/accounts/total-balance/1
	public double getTotalBalanceByCustomerId(@PathVariable("customerId") long customerId) {
		double totalBalance = accountService.getTotalBalanceByCustomerId(customerId);
		return totalBalance;
	}
}