package com.fis.bankapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fis.bankapplication.model.Account;

@Repository
@Transactional
public interface AccountRepo extends JpaRepository<Account, Long> {

//	DSL Grammar	

//	deposit	method
	@Modifying
	@Query("UPDATE Account a SET a.balance = a.balance + :amount WHERE a.id = :accountId")
	void deposit(@Param("accountId") long accountId, @Param("amount") double amount);

//	withdraw method
	@Modifying
	@Query("UPDATE Account a SET a.balance = a.balance - :amount WHERE a.id = :accountId")
	void withdraw(@Param("accountId") long accountId, @Param("amount") double amount);

//	fund transfer method
	@Modifying
	@Query("UPDATE Account fromAccount SET fromAccount.balance = fromAccount.balance - :amount WHERE fromAccount.id = :fromAccountNumber")
	void fundTransferFrom(@Param("fromAccountNumber") long fromAccountNumber, @Param("amount") double amount);

//  Update account method
	@Modifying
	@Query("UPDATE Account toAccount SET toAccount.balance = toAccount.balance + :amount WHERE toAccount.id = :toAccountNumber")
	void fundTransferTo(@Param("toAccountNumber") long toAccountNumber, @Param("amount") double amount);

//	Find by customer id method
	public List<Account> findByCustomer_Id(long customerId);

//	Adding up balance by customer id method
	@Query("SELECT SUM(a.balance) FROM Account a WHERE a.customer.id = :customerId")
	public double sumBalanceByCustomerId(@Param("customerId") long customerId);

}